# Changelog

## 2026.1.21

### Changes
- Version alignment with core Clawdbot release numbers.

## 2026.1.20

### Changes
- Version alignment with core Clawdbot release numbers.

## 2026.1.17-1

### Changes
- Version alignment with core Clawdbot release numbers.

## 2026.1.17

### Changes
- Version alignment with core Clawdbot release numbers.

## 2026.1.16

### Changes
- Version alignment with core Clawdbot release numbers.

## 2026.1.15

### Changes
- Version alignment with core Clawdbot release numbers.

## 2026.1.14

### Changes
- Version alignment with core Clawdbot release numbers.

## 0.1.0

### Features
- Zalo Bot API channel plugin with token-based auth (env/config/file).
- Direct message support (DMs only) with pairing/allowlist/open/disabled policies.
- Polling and webhook delivery modes.
- Text + image messaging with 2000-char chunking and media size caps.
- Multi-account support with per-account config.
