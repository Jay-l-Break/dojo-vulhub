// Templates
import './views/creationDialog/CreateDiscussion';
import './views/DiscussionTabbar';

// Other UI extensions
import './lib/messageTypes/discussionMessage';
import './createDiscussionMessageAction';
import './discussionFromMessageBox';
import './tabBar';

import '../lib/discussionRoomType';

// Style
import './public/stylesheets/discussion.css';
