function foo() {
  (() => foo())();
}
