function foo() {
  x = true;
}
