export const bar = 'bar'
