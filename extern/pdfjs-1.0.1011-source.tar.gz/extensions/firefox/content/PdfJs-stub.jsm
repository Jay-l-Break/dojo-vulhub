/* -*- Mode: Java; tab-width: 2; indent-tabs-mode: nil; c-basic-offset: 2 -*- */
/* vim: set shiftwidth=2 tabstop=2 autoindent cindent expandtab: */
/* Copyright 2012 Mozilla Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/* jshint esnext:true, maxlen:100 */

'use strict';

// Don't remove this file. FF15+ expects PdfJs module to be present at resource://pdf.js/PdfJs.jsm
// See https://mxr.mozilla.org/mozilla-central/source/browser/components/nsBrowserGlue.js
var EXPORTED_SYMBOLS = ['PdfJs'];

let PdfJs = {
  init: function PdfJs_init() {}
};
