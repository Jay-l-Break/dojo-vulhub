export const hello = () => 'world'
